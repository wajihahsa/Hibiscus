# 🌺 Bunga Sepatu Website

Website sederhana bertema bunga sepatu (hibiscus).

## Fitur
- Informasi dasar bunga sepatu
- Fakta menarik
- Desain simpel dan elegan

## Cara Menjalankan
Buka file `index.html` di browser.

## Author
Gudhal Production
